package ast;

public abstract class AstCfield extends AstNode{
    public AstCfield(String derivation, int lineNum) {
        super(derivation, lineNum);
    }
}
