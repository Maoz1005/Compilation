package ast;

public abstract class AstDec extends AstNode {
  public AstDec(String derivation, int lineNum) {
    super(derivation, lineNum);
  }
  
}
