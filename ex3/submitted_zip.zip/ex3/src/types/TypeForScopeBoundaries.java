package types;

public class TypeForScopeBoundaries extends Type
{
	/****************/
	/* CTROR(S) ... */
	/****************/
	public TypeForScopeBoundaries(String name)
	{
		this.name = name;
	}
}
