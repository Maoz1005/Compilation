package types;

public class TypeClassMemberDec {
    public Type t;
    public String name; // ID of the member

    public TypeClassMemberDec(Type t, String name) {
        this.t = t;
        this.name = name;
    }
}
